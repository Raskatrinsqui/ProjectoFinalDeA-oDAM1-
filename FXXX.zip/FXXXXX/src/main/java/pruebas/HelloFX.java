package pruebas;

import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.image.Image;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundImage;
import javafx.scene.layout.BackgroundPosition;
import javafx.scene.layout.BackgroundRepeat;
import javafx.scene.layout.BackgroundSize;
import javafx.scene.layout.StackPane;
import javafx.stage.Stage;

public class HelloFX extends Application {
    @Override
    public void start(Stage primaryStage) {
        // Carga la imagen que deseas usar como fondo
        Image backgroundImage = new Image("pun.png");
     
        Button btn = new Button();
        btn.setText("BELLEZA");
        // Crea un objeto BackgroundImage
        StackPane root = new StackPane();
        root.getChildren().add(btn);
       
        EventHandler<ActionEvent> eventHandler = new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                BackgroundImage background = new BackgroundImage(
            backgroundImage,
            BackgroundRepeat.NO_REPEAT,
            BackgroundRepeat.NO_REPEAT,
            BackgroundPosition.DEFAULT,
            BackgroundSize.DEFAULT
        );
                Background backgroundFinal = new Background(background);
                root.setBackground(backgroundFinal);
                root.getChildren().remove(btn);
            }
        };
     
        // Crea un objeto Background con la imagen de fondo
          btn.setOnAction(eventHandler);
        

        // Crea un contenedor StackPane para tu escena
       
      
        // Crea la escena y configura el tamaño
        Scene scene = new Scene(root, 800, 600);

        // Configura la escena principal y muéstrala
        primaryStage.setTitle("Mi aplicación JavaFX");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }
}