package pruebas;

import java.awt.Font;
import java.io.IOException;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDPage;
import org.apache.pdfbox.pdmodel.PDPageContentStream;
import org.apache.pdfbox.pdmodel.font.PDType0Font;
import org.apache.pdfbox.pdmodel.font.PDType1Font;

public class PDFCreator {
    public static void main(String[] args) {
        String filename = "documento.pdf";

        try (PDDocument document = new PDDocument()) {
            PDPage page = new PDPage();
            document.addPage(page);

            try (PDPageContentStream contentStream = new PDPageContentStream(document, page)) {
            	 PDType0Font font = PDType0Font.load(document, Botones.class.getResourceAsStream("C:\\Users\\mañana\\eclipse-workspace\\FXXXXX\\src\\main\\resources\\Fonts\\Rubik-Regular.ttf"));

            	contentStream.setFont(font,12);
                contentStream.beginText();
                contentStream.newLineAtOffset(100, 700);
                contentStream.showText("¡Hola, este es un documento PDF creado con Java y PDFBox!");
                contentStream.endText();
            }

            document.save(filename);
            System.out.println("Documento PDF creado correctamente: " + filename);
        } catch (IOException e) {
            System.err.println("Error al crear el documento PDF: " + e.getMessage());
        }
    }
}