package pruebas;
import org.apache.poi.ss.usermodel.*;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

public class LeerExcel {
	public static void main(String[] args) {
        String archivoExcel = "C:\\Users\\mañana\\Desktop\\popop\\Excel.xlsx";
        
        try {
            FileInputStream fis = new FileInputStream(archivoExcel);
            Workbook workbook = WorkbookFactory.create(fis);
            
            Sheet sheet = workbook.getSheetAt(0); 
           
            int endRow = 2+AumentarJuegos.numeroActual();

           
            for (int i =2; i < endRow; i++) {
                Row row = sheet.getRow(i);
                Cell cell =	row.getCell(2);
                    if (cell != null) {
                        
                     System.out.print(cell.getStringCellValue()+" " +Precio.get(row) + "\n");
                        
                        
                    } else {
                        System.out.print("\n");
                    }
                }
             
            
            
            workbook.close();
            fis.close();
            
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}