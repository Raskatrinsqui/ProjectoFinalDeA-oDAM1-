package pruebas;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;

public class Precio {
public static double get(Row row) {
	
        String archivoExcel = "C:\\Users\\mañana\\Desktop\\popop\\Excel.xlsx";
        
        try {
            FileInputStream fis = new FileInputStream(archivoExcel);
            Workbook workbook = WorkbookFactory.create(fis);
            
            Sheet sheet = workbook.getSheetAt(0); // Hoja de Excel (índice 0)
            
            
            double valor = row.getCell(3).getNumericCellValue();
            
          
            
           
            workbook.close();
           
            fis.close();
            return valor;
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return 59.99;
    }
}