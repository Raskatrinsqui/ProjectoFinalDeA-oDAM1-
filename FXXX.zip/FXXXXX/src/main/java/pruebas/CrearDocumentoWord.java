package pruebas;

import java.io.FileOutputStream;
import org.apache.poi.xwpf.usermodel.*;

public class CrearDocumentoWord {
    public static void main(String[] args) {
        try (XWPFDocument documento = new XWPFDocument()) {
            // Crear un párrafo y agregar texto
            XWPFParagraph paragraph = documento.createParagraph();
            XWPFRun run = paragraph.createRun();
            run.setText("¡Hola, este es un documento Word creado desde Java!");

            // Guardar el documento en el sistema de archivos
            try (FileOutputStream out = new FileOutputStream("C:\\Users\\PEDRORECIO\\OneDrive\\Escritorio\\popop\\documento_word.docx")) {
                documento.write(out);
                System.out.println("Documento Word creado exitosamente.");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}