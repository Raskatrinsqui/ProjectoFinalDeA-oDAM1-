package pruebas;

import java.io.FileOutputStream;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDPage;
import org.apache.pdfbox.pdmodel.PDPageContentStream;
import org.apache.pdfbox.pdmodel.font.PDType0Font;
import org.apache.pdfbox.pdmodel.font.PDType1Font;
import org.apache.poi.xwpf.usermodel.XWPFDocument;

import java.io.FileInputStream;
import java.io.FileOutputStream;

import org.apache.poi.xwpf.usermodel.XWPFDocument;
import org.apache.poi.xwpf.usermodel.XWPFParagraph;
import org.apache.poi.xwpf.usermodel.XWPFRun;

import javafx.application.Application;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.layout.HBox;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;

import javafx.scene.text.Text;
import javafx.stage.Stage;

public class Botones extends Application{
	
	@Override
	    public void start(Stage primaryStage) {
	     Button btn = new Button("boton 1");
	     Button btnf= new Button("FIN");
	  // Cambiar el color de fondo del botón
	    

	     // Cambiar el color del texto del botón
	
	     btn.setStyle("-fx-background-color: #7B6560; -fx-text-fill: white;");    
	   
	     System.out.println("Estilo del botón: " + btn.getStyle());

	     HBox cajaParaWord = new HBox();
	     Button creaWord = new Button("Crear .docx");
	     TextField contenidoWord = new TextField();
	     
	  
	     Button creaPDF = new Button("Crear .pdf");
	   
	     contenidoWord.resize(40, 60);
	     EventHandler<ActionEvent> wordFin = new EventHandler<ActionEvent>(){

			@Override
			public void handle(ActionEvent event) {
				// TODO Auto-generated method stub
				 try (XWPFDocument documento = new XWPFDocument()) {
			           
			            XWPFParagraph paragraph = documento.createParagraph();
			            XWPFRun run = paragraph.createRun();
			            run.setText(contenidoWord.getText());

			            // Guardar el documento en el sistema de archivos
			            try (FileOutputStream out = new FileOutputStream("C:\\Users\\mañana\\Desktop\\popop\\documento_word.docx")) {
			                documento.write(out);
			                System.out.println("Documento Word creado exitosamente.");
			            }
			        } catch (Exception e) {
			            e.printStackTrace();
			        }
			}
	    	 
	     };
	     EventHandler<ActionEvent> pdfFin = new EventHandler<ActionEvent>(){

				@Override
				public void handle(ActionEvent event) {
					// TODO Auto-generated method stub
					 try (XWPFDocument documento = new XWPFDocument()) {
				            // Crear un párrafo y agregar texto
				            XWPFParagraph paragraph = documento.createParagraph();
				            XWPFRun run = paragraph.createRun();
				            run.setText(contenidoWord.getText());

				            // Guardar el documento en el sistema de archivos
				            try (FileOutputStream out = new FileOutputStream("C:\\Users\\mañana\\Desktop\\popop\\documento_word.docx")) {
				                documento.write(out);
				                System.out.println("Documento Word creado exitosamente.");
				                convert("C:\\Users\\mañana\\Desktop\\popop\\documento_word.docx","C:\\Users\\mañana\\Desktop\\popop\\documento_pdf.pdf");
				            }
				        } catch (Exception e) {
				            e.printStackTrace();
				        }
				}
		    	 
		     };
		     creaPDF.setOnAction(pdfFin);
	     creaWord.setOnAction(wordFin);
	     cajaParaWord.getChildren().addAll(contenidoWord,creaWord,creaPDF);
	     
	     HBox cajaTexto = new HBox();
	    
	     TextField text = new TextField();
	     Button guardarButton = new Button("Guardar");
	     VBox hbox = new VBox();
	     Text texto = new Text("Texto de prueba");
	        guardarButton.setOnAction(e -> {
	        	String textoIngresado = " ";
	            textoIngresado += text.getText()+" ";
	            Text textoEscrito = new Text(textoIngresado);
	            text.clear();
	            hbox.getChildren().addAll(textoEscrito);
	            System.out.println("Texto ingresado: " + textoIngresado);
	            // Aquí puedes hacer lo que quieras con el texto ingresado, como guardarlo en una variable o en una base de datos
	        });
	     EventHandler<ActionEvent> eventHandler = new EventHandler<ActionEvent>() {
	    	 
			@Override
			public void handle(ActionEvent event) {
				// TODO Auto-generated method stub
				System.out.println("aaaaaaaaaa");
			}
	    	 
	     } ;
	     EventHandler<ActionEvent> fin = new EventHandler<ActionEvent>() {

	 		@Override
	 		public void handle(ActionEvent event) {
	 			// TODO Auto-generated method stub
	 			Platform.exit();
	 		}
	     	 
	      } ;
	      cajaTexto.getChildren().addAll(text,guardarButton);
	     
	      texto.setStyle("-fx-color: blue");
	     btn.setOnAction(eventHandler);
	     btn.setPrefWidth(200);
	     btn.setPrefHeight(100);
	     btnf.setOnAction(fin);
	     StackPane root = new StackPane();
	    
	     	hbox.getChildren().addAll(texto,cajaTexto,cajaParaWord);
	        hbox.getChildren().addAll(btn, btnf);
	        hbox.setSpacing(22);
	        
	        // Crear una escena y configurarla en la ventana
	        Scene scene = new Scene(hbox, 1200, 400);
	     
	        //scene.getStylesheets().add(getClass().getResource("/com/ejemplo/styles.css").toExternalForm());
	        primaryStage.setScene(scene);
	        primaryStage.setTitle("Dos botones separados");
	        primaryStage.show();
	    }
	
	 public static void convert(String inputWordFile, String outputPdfFile) throws Exception {
	        // Cargar el documento Word
	        XWPFDocument document = new XWPFDocument(new FileInputStream(inputWordFile));

	        // Crear un nuevo documento PDF
	        PDDocument pdfDocument = new PDDocument();
	        PDPage page = new PDPage();
	        pdfDocument.addPage(page);

	        // Inicializar el contenido del PDF
	        PDPageContentStream contentStream = new PDPageContentStream(pdfDocument, page);

	        // Agregar el contenido del documento Word al PDF
	        PDType0Font font = PDType0Font.load(pdfDocument, Botones.class.getResourceAsStream("Jersey_15/Jersey15-Regular.ttf"));

	        // Agregar el contenido del documento Word al PDF
	        contentStream.beginText();
	   	 contentStream.setFont(font, 12); // Usamos la fuente cargada
	      //  contentStream.setFont(font, 12); // Usamos la fuente cargada
	        contentStream.newLineAtOffset(100, 700);
	        for (XWPFParagraph paragraph : document.getParagraphs()) {
	        	 contentStream.setFont(font, 12); // Usamos la fuente cargada
	            contentStream.showText(paragraph.getText());
	            contentStream.newLine();
	        }
	        contentStream.endText();

	        // Cerrar el contenido del PDF
	        contentStream.close();

	        // Guardar el documento PDF
	        pdfDocument.save(outputPdfFile);
	        pdfDocument.close();
	    }

	    public static void main(String[] args) {
	        launch(args);
	    }

		
}
