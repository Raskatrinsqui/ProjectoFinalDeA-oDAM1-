package pruebas;

import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDPage;
import org.apache.pdfbox.pdmodel.PDPageContentStream;
import org.apache.pdfbox.pdmodel.font.PDType0Font;
import org.apache.poi.xwpf.usermodel.XWPFDocument;
import org.apache.poi.xwpf.usermodel.XWPFParagraph;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;

public class Convertor {
	 public static void convert(String inputWordFile, String outputPdfFile) throws Exception {
		
		        // Cargar el documento Word
		        XWPFDocument document = new XWPFDocument(new FileInputStream(inputWordFile));

		        // Crear un nuevo documento PDF
		        PDDocument pdfDocument = new PDDocument();
		        PDPage page = new PDPage();
		        pdfDocument.addPage(page);

		        // Inicializar el contenido del PDF
		        PDPageContentStream contentStream = new PDPageContentStream(pdfDocument, page);

		        // Cargar la fuente TrueType
		        try (InputStream inputStream = Convertor.class.getResourceAsStream("C:\\Users\\PEDRORECIO\\Downloads\\Jersey_15")) {
		            PDType0Font font = PDType0Font.load(pdfDocument, inputStream);
		    
		            // Agregar el contenido del documento Word al PDF
		            contentStream.beginText();
		            contentStream.setFont(font, 12); // Usamos la fuente cargada
		            contentStream.newLineAtOffset(100, 700);
		            for (XWPFParagraph paragraph : document.getParagraphs()) {
		                contentStream.showText(paragraph.getText());
		                contentStream.newLine();
		            }
		            contentStream.endText();
		        }

		        // Cerrar el contenido del PDF
		        contentStream.close();

		        // Guardar el documento PDF
		        pdfDocument.save(outputPdfFile);
		        pdfDocument.close();
		    }


	    public static void main(String[] args) {
	        try {
	            convert("C:\\Users\\PEDRORECIO\\OneDrive\\Escritorio\\popop\\documento_word.docx","C:\\Users\\PEDRORECIO\\OneDrive\\Escritorio\\popop\\documento_pdf.pdf");
	            System.out.println("Documento PDF creado exitosamente.");
	        } catch (Exception e) {
	            e.printStackTrace();
	        }
	    }
	}

