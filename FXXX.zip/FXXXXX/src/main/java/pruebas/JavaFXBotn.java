package pruebas;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundImage;
import javafx.scene.layout.BackgroundPosition;
import javafx.scene.layout.BackgroundRepeat;
import javafx.scene.layout.BackgroundSize;
import javafx.scene.layout.StackPane;
import javafx.stage.Stage;

public class JavaFXBotn extends Application {
    @Override
    public void start(Stage primaryStage) {
        // Carga la imagen que deseas usar como fondo
        Image backgroundImage = new Image("pun.png");

        // Crea un objeto BackgroundImage
        BackgroundImage background = new BackgroundImage(
            backgroundImage,
            BackgroundRepeat.NO_REPEAT,
            BackgroundRepeat.NO_REPEAT,
            BackgroundPosition.DEFAULT,
            BackgroundSize.DEFAULT
        );

        // Crea un objeto Background con la imagen de fondo
        Background backgroundFinal = new Background(background);

        // Crea un contenedor StackPane para tu escena
        StackPane root = new StackPane();
        root.setBackground(backgroundFinal);

        // Crea la escena y configura el tamaño
        Scene scene = new Scene(root, 800, 600);

        // Configura la escena principal y muéstrala
        primaryStage.setTitle("Mi aplicación JavaFX");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }
}