package pruebas;
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.StackPane;
import javafx.stage.Stage;

public class VentanaUnBoton extends Application {

    private Stage primaryStage;

    @Override
    public void start(Stage primaryStage) {
        this.primaryStage = primaryStage;

        Button boton = new Button("Abrir Ventana");
        boton.setOnAction(e -> {
            boton.setDisable(true); // Deshabilitar el botón al presionarlo
            abrirVentana();
        });

        StackPane layout = new StackPane();
        layout.getChildren().add(boton);

        Scene scene = new Scene(layout, 300, 200);

        primaryStage.setScene(scene);
        primaryStage.setTitle("Ventana Principal");
        primaryStage.show();
    }

    private void abrirVentana() {
        Stage stage = new Stage();
        stage.setTitle("Ventana Secundaria");

        stage.setOnCloseRequest(e -> primaryStage.show()); // Mostrar la ventana principal al cerrar la ventana secundaria

        stage.setOnHidden(e -> {
            primaryStage.show(); // Mostrar la ventana principal cuando la ventana secundaria se oculte
            ((Button) primaryStage.getScene().getRoot().getChildrenUnmodifiable().get(0)).setDisable(false); // Habilitar el botón nuevamente
        });

        StackPane layout = new StackPane();
        Scene scene = new Scene(layout, 200, 150);
        stage.setScene(scene);

        stage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }
}