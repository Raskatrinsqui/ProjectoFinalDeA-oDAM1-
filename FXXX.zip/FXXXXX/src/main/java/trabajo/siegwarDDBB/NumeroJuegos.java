package trabajo.siegwarDDBB;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;

public class NumeroJuegos {
	public static int numeroActual() {
		 String archivoExcel = "C:\\Users\\mañana\\Desktop\\popop\\Excel.xlsx";
	        
	        try {
	        	  FileInputStream fis = new FileInputStream(archivoExcel);
	              Workbook workbook = WorkbookFactory.create(fis);
	              Sheet sheet = workbook.getSheet("Hoja1");
	              Row row = sheet.getRow(1);
	              Cell cell = row.getCell(1);
	            //  System.out.println((int)cell.getNumericCellValue());
	         
	             return (int)cell.getNumericCellValue();
	             
	          } catch (FileNotFoundException e) {
	              e.printStackTrace();
	          } catch (IOException e) {
	              e.printStackTrace();
	          }
	        return 20;
	} 
	public static void aumenta() {
		 String archivoExcel = "C:\\Users\\mañana\\Desktop\\popop\\Excel.xlsx";
	        
	        try {
	        	FileInputStream fis = new FileInputStream(archivoExcel);
	              Workbook workbook = WorkbookFactory.create(fis);
	              Sheet sheet = workbook.getSheet("Hoja1");
	              Row row = sheet.getRow(1);
	              Cell cell = row.getCell(1);
	              
	            
	              if(!((Double)cell.getNumericCellValue()).equals( null)){
	              double valor = cell.getNumericCellValue();
	              System.out.println("Valor original de la celda: " + valor);
	              
	              
	              valor++;
	              
	              
	              cell.setCellValue(valor);
	              
	             
	              FileOutputStream fos = new FileOutputStream(archivoExcel);
	              workbook.write(fos);
	              workbook.close();
	              fis.close();
	              fos.close();
	              
	              System.out.println("Se ha incrementado el valor en 1 y se ha guardado en el archivo Excel.");
	              }else {
	            	  cell.setCellValue(1);
	              }
	          } catch (FileNotFoundException e) {
	              e.printStackTrace();
	          } catch (IOException e) {
	              e.printStackTrace();
	          }
	}
	public static void disminuir() {
		 String archivoExcel = "C:\\Users\\mañana\\Desktop\\popop\\Excel.xlsx";
	        
	        try {
	        	  FileInputStream fis = new FileInputStream(archivoExcel);
	              Workbook workbook = WorkbookFactory.create(fis);
	              Sheet sheet = workbook.getSheet("Hoja1");
	              Row row = sheet.getRow(1);
	              Cell cell = row.getCell(1);
	              
	         
	              if(!((Double)cell.getNumericCellValue()).equals( null)){
	              double valor = cell.getNumericCellValue();
	             
	      
	              valor--;
	              
	              cell.setCellValue(valor);
	        
	              FileOutputStream fos = new FileOutputStream(archivoExcel);
	              workbook.write(fos);
	              workbook.close();
	              fis.close();
	              fos.close();
	              
	              
	              }else {
	            	  cell.setCellValue(0);
	              }
	              
	          } catch (FileNotFoundException e) {
	              e.printStackTrace();
	          } catch (IOException e) {
	              e.printStackTrace();
	          }
	}
}
