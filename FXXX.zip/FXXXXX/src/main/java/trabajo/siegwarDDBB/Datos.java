package trabajo.siegwarDDBB;

import java.io.FileOutputStream;

import org.apache.poi.xwpf.usermodel.XWPFDocument;
import org.apache.poi.xwpf.usermodel.XWPFParagraph;
import org.apache.poi.xwpf.usermodel.XWPFRun;

import javafx.application.Application;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundFill;
import javafx.scene.layout.CornerRadii;
import javafx.scene.layout.HBox;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Text;
import javafx.stage.Stage;

public class Datos {
	   public static void mostrar() {
	        Stage ventana = new Stage();
	        ventana.setTitle("Datos");
	        
	       
	        
	        
	        Label label = new Label("Datos");
	        label.setStyle("-fx-background-color: #BDCBC7; -fx-text-fill: #373838; -fx-padding: 10px;-fx-font-size:30px;-fx-padding-: 10px 40px");
	        Label resultado = new Label();
	        HBox cajaTexto = new HBox();
	        cajaTexto.setAlignment(Pos.CENTER);
	        
		    TextField objetivo= new TextField();
		    Button buscar = new Button("Buscar");
		   
	
		    buscar.setOnAction(e -> {
		    	
		    	resultado.setText(null);
		    	String nombre = TrabajaExcel.proveedorDeDatos(objetivo.getText());
		    	if (nombre ==null) {
		    		resultado.setText("Error juego no encontrado");
			    	resultado.setStyle("-fx-background-color: #DF4A4A; -fx-text-fill: #373838;");
		    	}else {
		    	resultado.setText(nombre);
		    	resultado.setStyle("-fx-background-color: #85988A; -fx-text-fill: #373838;");
		    	}
		    });
		    
		    ventana.setOnHidden(e -> Ventana.cambiarComprobante());
		    
		    Button fin = new Button("Atras");
		    fin.setStyle("-fx-background-color: #95CDBC;");
		    fin.setOnAction(e ->{ventana.close();} );
		  
		    HBox botone = new HBox();
		    botone.setAlignment(Pos.CENTER);
	        botone.getChildren().addAll(fin);
	        
		    cajaTexto.getChildren().addAll(objetivo,buscar);
	        VBox principal = new VBox(50);
	        principal.getChildren().addAll(label,cajaTexto,resultado,botone);
	        principal.setBackground(new Background(new BackgroundFill(Color.web("#54645F"), CornerRadii.EMPTY, Insets.EMPTY)));
	        principal.setAlignment(Pos.CENTER);
	        principal.setPadding(new Insets(10));
	        ventana.setScene(new Scene(principal, 450, 450));

	        ventana.show();
	    }
	  
}
