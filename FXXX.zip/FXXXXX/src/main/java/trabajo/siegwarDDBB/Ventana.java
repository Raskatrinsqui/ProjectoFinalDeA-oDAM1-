package trabajo.siegwarDDBB;

import java.io.FileOutputStream;

import org.apache.poi.xwpf.usermodel.XWPFDocument;
import org.apache.poi.xwpf.usermodel.XWPFParagraph;
import org.apache.poi.xwpf.usermodel.XWPFRun;

import javafx.application.Application;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundFill;
import javafx.scene.layout.CornerRadii;
import javafx.scene.layout.HBox;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import trabajo.numble.TrabajarMucho;

public class Ventana extends Application{
	 private Stage primaryStage;
	 private static int comprobante = 0;
	public Stage getPrimaryStage() {
		return primaryStage;
	}
	public static void cambiarComprobante() {
		if(comprobante == 0) {
			comprobante = 1;
		}else {
			comprobante =0;
		}
	}
	@Override
    public void start(Stage primaryStage) {
 
		   this.primaryStage = primaryStage;
     

      Label label = new Label("SiegwarDDBB");
      label.setStyle("-fx-background-color: #BDCBC7; -fx-text-fill: #373838; -fx-padding: 10px;-fx-font-size:80px;");
      // Crear los botones
      Button botonD = new Button("Datos");
      Button botonA = new Button("Añadir");
      Button botonB = new Button("Borrar");
      Button salida = new Button("Salir");
      Button botonT = new Button("Trabajar");
      botonD.setOnAction(e->{
    	 if(comprobante == 0) {
    	  Datos.mostrar();
    	  cambiarComprobante();
    	 }
    	 });

      
      botonA.setOnAction(e->{
    	  if(comprobante == 0) {
    		  Añadir.mostrar();
    		  cambiarComprobante();
    	  }
    	  });	
      
      
      botonB.setOnAction(e -> {
     	 if(comprobante == 0) {	 
     	 Borrar.mostrar();
     	 cambiarComprobante();
	  }
	  });
      botonT.setOnAction(e -> {
      	 if(comprobante == 0) {	 
      	 TrabajarMucho.mostrar();
      	 cambiarComprobante();
 	  }
 	  });
      // Ajustar el tamaño de los botones
      botonD.setPrefSize(250, 100);
      botonA.setPrefSize(250, 100);
      botonB.setPrefSize(250, 100);
      salida.setPrefSize(250, 100);
      botonT.setPrefSize(75,20);
      
      botonD.setStyle("-fx-background-color: #95CDBC;");
      botonA.setStyle("-fx-background-color: #95CDBC;");
      botonB.setStyle("-fx-background-color: #95CDBC;");
      salida.setStyle("-fx-background-color: #95CDBC;");
      botonT.setStyle("-fx-background-color: #95CDBC;");
      
      salida.setOnAction(e -> Platform.exit());
     
      VBox principal = new VBox(50); // Espacio entre los elementos
      HBox	box1 = new HBox(100); 
      box1.setAlignment(Pos.CENTER);
      HBox box2 = new HBox(100); 
      box2.setAlignment(Pos.CENTER);
      
      box1.getChildren().addAll(botonD,botonA);
      box2.getChildren().addAll(botonB,salida);
      
      principal.getChildren().addAll(label, box1, box2,botonT);
      principal.setBackground(new Background(new BackgroundFill(Color.web("#54645F"), CornerRadii.EMPTY, Insets.EMPTY)));

     
      principal.setAlignment(Pos.CENTER);
      principal.setPadding(new Insets(10));

     
      Scene scene = new Scene(principal, 1200, 600);
    
      
      primaryStage.setScene(scene);
      primaryStage.setTitle("SiegwarDDBB");
      primaryStage.show();
    }
	  public static void main(String[] args) {
	        launch(args);
	    }

		
}

