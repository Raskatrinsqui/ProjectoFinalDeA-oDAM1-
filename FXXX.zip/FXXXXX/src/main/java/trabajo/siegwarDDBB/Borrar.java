package trabajo.siegwarDDBB;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundFill;
import javafx.scene.layout.CornerRadii;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.stage.Stage;

public class Borrar {
	 public static void mostrar() {
		   Stage ventana = new Stage();
		    ventana.setOnHidden(e -> Ventana.cambiarComprobante());
	        ventana.setTitle("Borrar");
	        
	        Label label = new Label("Borrar dato");
	        label.setStyle("-fx-background-color: #BDCBC7; -fx-text-fill: #373838; -fx-padding: 10px;-fx-font-size:30px;-fx-padding-: 10px 40px");
	        
	        HBox cajaNombre = new HBox(15);
	        cajaNombre.setAlignment(Pos.CENTER);
	        Label lNombre = new Label("Nombre");
		    TextField tfNombre= new TextField();
		    cajaNombre.getChildren().addAll(lNombre,tfNombre);
		    
		    HBox cajaContrasena = new HBox(5);
		    cajaContrasena.setAlignment(Pos.CENTER);
	        Label lContrasena = new Label("Contraseña");
		    TextField tfContrasena= new TextField();
		    cajaContrasena.getChildren().addAll(lContrasena,tfContrasena);
		    
		    Label resultado = new Label();
		    
		    HBox botones = new HBox(20);
		    Button borrar = new Button("Borrar");
		    borrar.setStyle("-fx-background-color: #95CDBC;");
		    borrar.setOnAction(e -> {
		    	String contra = tfContrasena.getText();
		    	String nombre = tfNombre.getText();
		    	resultado.setText(TrabajaExcel.borrarJuego(contra, nombre));
		    	
		    });
		    Button fin = new Button("Atras");
		    fin.setStyle("-fx-background-color: #95CDBC;");
		    fin.setOnAction(e ->{ventana.close();} );
	        
	       botones.getChildren().addAll(borrar,fin);
	        botones.setAlignment(Pos.CENTER);
		    
	        VBox principal = new VBox(50);
	        principal.getChildren().addAll(label,cajaNombre,cajaContrasena,resultado,botones);
	        principal.setBackground(new Background(new BackgroundFill(Color.web("#54645F"), CornerRadii.EMPTY, Insets.EMPTY)));
	        principal.setAlignment(Pos.CENTER);
	        principal.setPadding(new Insets(10));
	        ventana.setScene(new Scene(principal, 450, 450));

	        ventana.show();}
}
