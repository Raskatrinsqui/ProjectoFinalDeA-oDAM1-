package trabajo.siegwarDDBB;

public class JuegoNoEncontradoException extends NullPointerException{

	public JuegoNoEncontradoException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public JuegoNoEncontradoException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
