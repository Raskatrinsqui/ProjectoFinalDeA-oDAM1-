package trabajo.siegwarDDBB;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;

public class TrabajaExcel {
	public static String borrarJuego(String contrasena, String nombre) {
		if (contrasena.equals("patata")) {
			String archivoExcel = "C:\\Users\\mañana\\Desktop\\popop\\Excel.xlsx";

			try {

				Integer filaAEliminar = proveedorDeRow(nombre);
				if (filaAEliminar == null)
					throw new JuegoNoEncontradoException();

				FileInputStream fis = new FileInputStream(archivoExcel);
				Workbook workbook = WorkbookFactory.create(fis);
				Sheet sheet = workbook.getSheet("Hoja1");

				// Obtener el número total de filas en la hoja
				int totalFilas = sheet.getLastRowNum();
				if (filaAEliminar >= 0 && filaAEliminar <= totalFilas) {

					sheet.shiftRows(filaAEliminar + 1, totalFilas, -1);
					Row row = sheet.getRow(totalFilas);

					if (row != null)
						sheet.removeRow(row);

					Row row1 = sheet.getRow(1);
					Cell cell = row1.getCell(1);
					cell.setCellValue(cell.getNumericCellValue() - 1);

					FileOutputStream fos = new FileOutputStream(archivoExcel);
					workbook.write(fos);
					workbook.close();
					fis.close();
					fos.close();
					return "Juego borrado";
				} else {
					System.out.println("La fila especificada no existe en la hoja.");
				}

			} catch (FileNotFoundException e) {
				e.printStackTrace();
			} catch (IOException e) {
				e.printStackTrace();
			} catch (JuegoNoEncontradoException e) {
				return "Juego no encontrado";
			}

		}
		return "Esa no es la contraseña";
	}

	public static Integer proveedorDeRow(String nombre) {
		String archivoExcel = "C:\\Users\\mañana\\Desktop\\popop\\Excel.xlsx";
		try {
			FileInputStream fis = new FileInputStream(archivoExcel);
			Workbook workbook = WorkbookFactory.create(fis);
			Sheet sheet = workbook.getSheet("Hoja1");

			for (int i = 2; i < NumeroJuegos.numeroActual() + 2; i++) {

				Row row = sheet.getRow(i);
				Cell cell = row.getCell(2);

				if (cell.getStringCellValue().toUpperCase().equals(nombre.toUpperCase())) {

					return i;
				}

			}
			return null;

		} catch (FileNotFoundException e) {
			e.printStackTrace();
			return null;
		} catch (IOException e) {
			e.printStackTrace();
			return null;
		}

	}

	public static String proveedorDeDatos(String nombre) {
		String archivoExcel = "C:\\Users\\mañana\\Desktop\\popop\\Excel.xlsx";
		try {
			FileInputStream fis = new FileInputStream(archivoExcel);
			Workbook workbook = WorkbookFactory.create(fis);
			Sheet sheet = workbook.getSheet("Hoja1");
			Integer numeroRow = proveedorDeRow(nombre);

			if (numeroRow == null)
				throw new JuegoNoEncontradoException();

			Row row = sheet.getRow(numeroRow);
			String precio = row.getCell(3).getStringCellValue();
			String compania = row.getCell(4).getStringCellValue();
			return String.format("Juego: %s%nPrecio: %s€%nCompañia: %s", nombre, precio, compania);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
			return null;
		} catch (IOException e) {
			e.printStackTrace();
			return null;
		} catch (JuegoNoEncontradoException e) {
			return null;
		}

	}

	public static String posicionador(String nombre, String precio, String compania) {
		String archivoExcel = "C:\\Users\\mañana\\Desktop\\popop\\Excel.xlsx";
		try {
			if (proveedorDeRow(nombre) == null) {
				FileInputStream fis = new FileInputStream(archivoExcel);
				Workbook workbook = WorkbookFactory.create(fis);
				Sheet sheet = workbook.getSheet("Hoja1");
				Row row = sheet.getRow(NumeroJuegos.numeroActual() + 2);

				Cell celda = row.createCell(2);
				celda.setCellValue(nombre);
				celda.setCellStyle(sheet.getRow(3).getCell(2).getCellStyle());

				Cell celdaPrecio = row.createCell(3);
				celdaPrecio.setCellValue(precio);
				celdaPrecio.setCellStyle(sheet.getRow(3).getCell(3).getCellStyle());

				Cell celdaCompania = row.createCell(4);
				celdaCompania.setCellValue(compania);
				celdaCompania.setCellStyle(sheet.getRow(3).getCell(4).getCellStyle());

				Row row1 = sheet.getRow(1);
				Cell cell = row1.getCell(1);
				cell.setCellValue(cell.getNumericCellValue() + 1);

				FileOutputStream fos = new FileOutputStream(archivoExcel);
				workbook.write(fos);
				workbook.close();
				fis.close();
				fos.close();
				return String.format("Juego: %s Precio: %s€  Compañia: %s%nCreado correctamente", nombre, precio,
						compania);
			}
			return "Juego repetido";
		} catch (FileNotFoundException e) {
			e.printStackTrace();
			System.out.println();
			return null;
		} catch (IOException e) {
			e.printStackTrace();
			return null;
		}
	}

	public static String proveedorDeDatosMasa(String objetivo, boolean precioOCompania) {
		String archivoExcel = "C:\\Users\\mañana\\Desktop\\popop\\Excel.xlsx";
		try {
			FileInputStream fis = new FileInputStream(archivoExcel);
			Workbook workbook = WorkbookFactory.create(fis);
			Sheet sheet = workbook.getSheet("Hoja1");
			String resultado="No hay datos";
			if(precioOCompania) {

				for (int i = 2; i < NumeroJuegos.numeroActual() + 2; i++) {

					Row row = sheet.getRow(i);
					Cell cell = row.getCell(3);

					if (cell.getStringCellValue().toUpperCase().equals(objetivo.toUpperCase())) {
						
						resultado = String.format("Juego: %s Precio: %s Compañia: %s%n",row.getCell(2).getStringCellValue(), row.getCell(3).getStringCellValue(),row.getCell(4).getStringCellValue());
						
					}

				}
			}else {
				for (int i = 2; i < NumeroJuegos.numeroActual() + 2; i++) {

				Row row = sheet.getRow(i);
				Cell cell = row.getCell(3);
				
				if(	cell.getCellType().toString().equals(cell.getStringCellValue())) {
				if (cell.getStringCellValue().toUpperCase().equals(objetivo.toUpperCase())) {
					
					resultado = String.format("Juego: %s Precio: %2.f Compañia: %s%n",row.getCell(2).getStringCellValue(), row.getCell(3).getNumericCellValue(),row.getCell(4).getStringCellValue());
					
				}

			}}}
		

			return resultado;
			
		} catch (FileNotFoundException e) {
			e.printStackTrace();
			return null;
		} catch (IOException e) {
			e.printStackTrace();
			return null;
		} catch (JuegoNoEncontradoException e) {
			return null;
		}

	}

}
