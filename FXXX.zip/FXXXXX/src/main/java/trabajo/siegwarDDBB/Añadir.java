package trabajo.siegwarDDBB;

import java.util.function.UnaryOperator;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.control.TextFormatter;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundFill;
import javafx.scene.layout.CornerRadii;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.stage.Stage;

public class Añadir {
	   public static void mostrar() {
		   Stage ventana = new Stage();
		    ventana.setOnHidden(e -> Ventana.cambiarComprobante());
	        ventana.setTitle("Añadir Juego");
	        
	        Label label = new Label("Añadir Juego");
	        label.setStyle("-fx-background-color: #BDCBC7; -fx-text-fill: #373838; -fx-padding: 10px;-fx-font-size:30px;-fx-padding-: 10px 40px");
	        
	        HBox cajaNombre = new HBox(15);
	        cajaNombre.setAlignment(Pos.CENTER);
	        Label lNombre = new Label("Nombre");
		    TextField tfNombre= new TextField();
		    cajaNombre.getChildren().addAll(lNombre,tfNombre);
		    
		    HBox cajaPrecio = new HBox(17);
		    cajaPrecio.setAlignment(Pos.CENTER);
	        Label lPrecio = new Label("Precio");
		    TextField tfPrecio= new TextField();
		    
		    // Filtro para que sea un double
		    UnaryOperator<TextFormatter.Change> filter = change -> {
	            String newText = change.getControlNewText();
	            if (newText.matches("-?([0-9]*\\,?[0-9]*)")) {
	                return change;
	            }
	            return null;
	        };

	        TextFormatter<String> textFormatter = new TextFormatter<>(filter);
	        tfPrecio.setTextFormatter(textFormatter);
		    cajaPrecio.getChildren().addAll(lPrecio,tfPrecio);
		    
		    HBox cajaCompania = new HBox(13);
		    cajaCompania.setAlignment(Pos.CENTER);
	        Label lCompania = new Label("Compañia");
		    TextField tfCompania= new TextField();
		    cajaCompania.getChildren().addAll(lCompania,tfCompania);
		    
		    Label lResultado = new Label();
		    
		    
		    HBox botones = new HBox(20);
		    Button anadir = new Button("Añadir");
		    anadir.setStyle("-fx-background-color: #95CDBC;");
		    anadir.setOnAction( e ->{
		    	lResultado.setText(null);
		    	if(tfNombre.getText().replace(" ", "").equals("")|| tfCompania.getText().replace(" ", "").equals("")|| tfPrecio.getText().replace(" ", "").equals("")) {
		    		lResultado.setText("Obligatorios todos los campos");
		    		lResultado.setStyle("-fx-background-color: #399673; -fx-text-fill: #373838;");
		    	}else {
		    	String resultado = TrabajaExcel.posicionador(tfNombre.getText(),tfPrecio.getText(),tfCompania.getText());
		    
		    	if (resultado ==null) {
		    		lResultado.setText("ERROR COLOSAL BUSCA AYUDA DE UN MAYOR DE EDAD");
		    		lResultado.setStyle("-fx-background-color: #DF4A4A; -fx-text-fill: #373838;");
		    	}else {
		    		lResultado.setText(resultado);
		    		lResultado.setStyle("-fx-background-color: #85988A; -fx-text-fill: #373838;");
		    	}}
		    });
		    
		    Button fin = new Button("Atras");
		    fin.setStyle("-fx-background-color: #95CDBC;");
		    fin.setOnAction(e ->{ventana.close();} );
	        
		    botones.getChildren().addAll(anadir,fin);
	        botones.setAlignment(Pos.CENTER);
	        
		    
	        VBox principal = new VBox(50);
	        principal.getChildren().addAll(label,cajaNombre,cajaPrecio,cajaCompania,lResultado,botones);
	        principal.setBackground(new Background(new BackgroundFill(Color.web("#54645F"), CornerRadii.EMPTY, Insets.EMPTY)));
	        principal.setAlignment(Pos.CENTER);
	        principal.setPadding(new Insets(10));
	        ventana.setScene(new Scene(principal, 450, 450));

	        ventana.show();
	    }
	   
}
