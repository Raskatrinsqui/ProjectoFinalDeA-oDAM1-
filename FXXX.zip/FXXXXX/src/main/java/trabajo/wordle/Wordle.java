package trabajo.wordle;

import java.util.List;

import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.TextField;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundFill;
import javafx.scene.layout.CornerRadii;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.stage.Stage;

public class Wordle extends Application{

	public static String palabraDelDia() {
		List<String> palabras = Palabras.diccionador();
		List<String> apsod=List.of(
				"aisndas",
				"oidnasdaso"
				);
		
		return palabras.get((int)(Math.random()*(palabras.size())));
		}
	@Override
    public void start(Stage primaryStage) {
		Stage ventana = primaryStage;
		ventana.setTitle("Numble");
		
		HBox letras1 = new HBox(10);
		letras1.setAlignment(Pos.CENTER);
		TextField letra1 = new TextField();
		//letras.setDisable(true);
		///letra1.setDisable(true);
		letra1.setPrefSize(50, 50);
		TextField letra2 = new TextField();
		letra2.setPrefSize(50, 50);
		TextField letra3 = new TextField();
		letra3.setPrefSize(50, 50);
		TextField letra4 = new TextField();
		letra4.setPrefSize(50, 50);
		TextField letra5 = new TextField();
		letra5.setPrefSize(50, 50);
		
		HBox letras2 = new HBox(10);
		letras2.setAlignment(Pos.CENTER);
		TextField letra2_1 = new TextField();
		
		letra2_1.setPrefSize(50, 50);
		TextField letra2_2 = new TextField();
		letra2_2.setPrefSize(50, 50);
		TextField letra2_3 = new TextField();
		letra2_3.setPrefSize(50, 50);
		TextField letra2_4 = new TextField();
		letra2_4.setPrefSize(50, 50);
		TextField letra2_5 = new TextField();
		letra2_5.setPrefSize(50, 50);
		
		letras2.getChildren().addAll(letra2_1,letra2_2,letra2_3,letra2_4,letra2_5);
		
		HBox letras3 = new HBox(10);
		letras3.setAlignment(Pos.CENTER);
		TextField letra3_1 = new TextField();
		
		letra3_1.setPrefSize(50, 50);
		TextField letra3_2 = new TextField();
		letra3_2.setPrefSize(50, 50);
		TextField letra3_3 = new TextField();
		letra3_3.setPrefSize(50, 50);
		TextField letra3_4 = new TextField();
		letra3_4.setPrefSize(50, 50);
		TextField letra3_5 = new TextField();
		letra3_5.setPrefSize(50, 50);
		
		letras3.getChildren().addAll(letra3_1,letra3_2,letra3_3,letra3_4,letra3_5);
		HBox letras4 = new HBox(10);
		letras4.setAlignment(Pos.CENTER);
		TextField letra4_1 = new TextField();
		letra4_1.setPrefSize(50, 50);
		TextField letra4_2 = new TextField();
		letra4_2.setPrefSize(50, 50);
		TextField letra4_3 = new TextField();
		letra4_3.setPrefSize(50, 50);
		TextField letra4_4 = new TextField();
		letra4_4.setPrefSize(50, 50);
		TextField letra4_5 = new TextField();
		letra4_5.setPrefSize(50, 50);
		
		letras4.getChildren().addAll(letra4_1,letra4_2,letra4_3,letra4_4,letra4_5);
		
		HBox letras5 = new HBox(10);
		letras5.setAlignment(Pos.CENTER);
		TextField letra5_1 = new TextField();
		letra5_1.setPrefSize(50, 50);
		TextField letra5_2 = new TextField();
		letra5_2.setPrefSize(50, 50);
		TextField letra5_3 = new TextField();
		letra5_3.setPrefSize(50, 50);
		TextField letra5_4 = new TextField();
		letra5_4.setPrefSize(50, 50);
		TextField letra5_5 = new TextField();
		letra5_5.setPrefSize(50, 50);
		
		letras5.getChildren().addAll(letra5_1,letra5_2,letra5_3,letra5_4,letra5_5);
		HBox letras6 = new HBox(10);
		letras6.setAlignment(Pos.CENTER);
		TextField letra6_1 = new TextField();
		letra6_1.setDisable(true);
		///letra1.setDisable(true);
		letra6_1.setPrefSize(50, 50);
		TextField letra6_2 = new TextField();
		letra6_2.setPrefSize(50, 50);
		TextField letra6_3 = new TextField();
		letra6_3.setPrefSize(50, 50);
		TextField letra6_4 = new TextField();
		letra6_4.setPrefSize(50, 50);
		TextField letra6_5 = new TextField();
		letra6_5.setPrefSize(50, 50);
		
		letras6.getChildren().addAll(letra6_1,letra6_2,letra6_3,letra6_4,letra6_5);
		VBox principal = new VBox(50);
		principal.getChildren().addAll(letras1,letras2,letras3,letras4,letras5,letras6);
		principal.setBackground(
				new Background(new BackgroundFill(Color.web("#E2E8F0"), CornerRadii.EMPTY, Insets.EMPTY)));
		principal.setAlignment(Pos.CENTER);
		principal.setPadding(new Insets(10));
		ventana.setScene(new Scene(principal, 1200, 720));

		ventana.show();
	}
	
	public static void main(String[] args) {
		launch(args);
	}
}
