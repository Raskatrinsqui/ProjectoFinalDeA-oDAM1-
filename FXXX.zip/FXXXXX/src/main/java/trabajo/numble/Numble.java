package trabajo.numble;

public class Numble {
private int resultado;
private String solucion;
private int[] numerosSolucion;
public int getResultado() {
	return resultado;
}
public String getSolucion() {
	return solucion;
}
public int[] getNumerosSolucion() {
	return numerosSolucion;
}
public Numble(int resultado, String solucion, int[] numerosSolucion) {
	super();
	this.resultado = resultado;
	this.solucion = solucion;
	this.numerosSolucion = numerosSolucion;
}

}
