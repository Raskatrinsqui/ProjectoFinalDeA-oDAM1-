package trabajo.numble;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundFill;
import javafx.scene.layout.CornerRadii;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.stage.Stage;
import trabajo.siegwarDDBB.Ventana;

public class TrabajarMucho {
	private static boolean numOSig = true;
	private static int resultado;
	private static boolean parentesis = false;
	private static List<String> historial = new ArrayList<>();
	private static List<Integer> historialNumerico = new ArrayList<>();
	private static void actuResultado(int i) {
		resultado = i;
	}

	public static int getResultado() {
		return resultado;
	}

	private static void setNumOSig(boolean bol) {
		TrabajarMucho.numOSig = bol;
	}

	private static void cambiarNumOSig() {
		if (numOSig) {
			numOSig = false;
		} else {
			numOSig = true;
		}
	}

	private static void cambiarParentesis() {
		if (parentesis) {
			parentesis = false;
		} else {
			parentesis = true;
		}
	}

	private static void borrarHistorial() {
		while (!historial.isEmpty()) {
			historial.remove(0);
		}
	}
	private static void borrarHistorialNumerico() {
		while (!historialNumerico.isEmpty()) {
			historialNumerico.remove(0);
		}
	}
	private static String delete(String actual) {
		if (historial.isEmpty()) {
			return "";
		}
		if(actual.equals("")) {
			return "";
		}
		char[] chari = actual.toCharArray();
		if(chari[chari.length-1] == '(' || chari[chari.length-1] == ')') {
			cambiarParentesis();
		}
		String ultimo = historial.get(historial.size() - 1);
		char[] chars = ultimo.toCharArray();
		if(chars[chars.length-1] == '(' || chars[chars.length-1] == ')') {
			
		}else {
			cambiarNumOSig();
		}
		historial.remove(historial.size() - 1);
		return ultimo;
	}

	private static void actualizar(String registro) {
		historial.add(registro);
	}
	private static void actualizarNumerico(int registro) {
		historialNumerico.add(registro);
	}
	public static Numble numble() {

		int[] numeros = { 5, 10, 15, 20, 25, 30, 35, 40, 45, 50, 55, 60, 65, 75, 75, 80, 85, 90, 95, 100, 1, 2, 3, 4, 6,
				7, 8, 9 };
		int[] numerosSolucion = new int[6];
		int solucion = 0;
		String solucionFinal = "";
		boolean comprobante, mulDiv = true;
		for (int i = 0; i < numerosSolucion.length; i++) {
			comprobante = true;
			int numeroRandom = (int) (Math.random() * (numeros.length));
			if (i == 0) {
				solucion = numeros[numeroRandom];
				numerosSolucion[i] = numeros[numeroRandom];
				solucionFinal += numeros[numeroRandom];
			} else {
				for (int numero : numerosSolucion) {
					if (numero == numeros[numeroRandom]) {
						comprobante = false;
					}

				}
				if (comprobante) {
					int operacion = (int) (Math.random() * (4)); // 0 = + || 1= - || 2= * || 3= /

					switch (operacion) {

					case 0:
						solucion += numeros[numeroRandom];
						numerosSolucion[i] = numeros[numeroRandom];
						solucionFinal += " + " + numeros[numeroRandom];
						break;
					case 1:
						if (solucion <= numeros[numeroRandom]) {
							i--;
						} else {
							solucion -= numeros[numeroRandom];
							numerosSolucion[i] = numeros[numeroRandom];
							solucionFinal += " - " + numeros[numeroRandom];
						}
						break;
					case 2:
						solucion *= numeros[numeroRandom];
						numerosSolucion[i] = numeros[numeroRandom];
						if (i == 1) {
							solucionFinal = "" + solucionFinal + " * " + numeros[numeroRandom];
						} else {
							solucionFinal = "(" + solucionFinal + ") * " + numeros[numeroRandom];
						}

						break;
					case 3:
						if (solucion <= numeros[numeroRandom] || solucion % numeros[numeroRandom] != 0) {
							i--;
						} else {
							solucion /= numeros[numeroRandom];
							numerosSolucion[i] = numeros[numeroRandom];
							if (i == 1) {
								solucionFinal = "" + solucionFinal + " / " + numeros[numeroRandom];
							} else {
								solucionFinal = "(" + solucionFinal + ") / " + numeros[numeroRandom];
							}
						}

						break;

					}

				} else {
					i--;
				}
			}

			if (solucion > 1000 || solucion< 100) {

				i = -1;
				solucion = 0;
				solucionFinal = "";
				for (int j = 0; j < numerosSolucion.length; j++) {
					numerosSolucion[j] = 0;
				}
			}
		}
		List<Integer> solucionShu = new ArrayList<>();
		for(int numero:numerosSolucion) {
			solucionShu.add(numero);
		}
		Collections.shuffle(solucionShu);
		for(int i =0; i<numerosSolucion.length;i++) {
			numerosSolucion[i]=(int)solucionShu.get(i);
			
		}
	
		return new Numble(solucion, solucionFinal,numerosSolucion );
	}

	public static void mostrar() {
		Stage ventana = new Stage();
		ventana.setTitle("Numble");
		ventana.setOnHidden(e ->{ 
			Ventana.cambiarComprobante();
		borrarHistorial();
		borrarHistorialNumerico();
		if(!numOSig) {
			cambiarNumOSig();
		}
		if(parentesis) {
			cambiarParentesis();
		}
			});
		Numble numble = numble();
		actuResultado(numble.getResultado());
		String solucion = numble.getSolucion();
		int[] numeros = numble.getNumerosSolucion();


		Label label = new Label("Numble");
		label.setStyle(
				"-fx-background-color: #E2E8F0; -fx-text-fill: #373838; -fx-padding: 10px;-fx-font-size:30px;-fx-padding-: 10px 40px");

		Button fin = new Button("Atras");
		fin.setStyle("-fx-background-color: #EF4444;");
		fin.setOnAction(e -> {
			ventana.close();
		});

		// NUMEROS
		Button numero1 = new Button(numeros[0] + "");
		numero1.setPrefSize(50, 75);
		numero1.setStyle("-fx-background-color: #1F2937;-fx-text-fill: #D1D5D6;");
		Button numero2 = new Button(numeros[1] + "");
		numero2.setPrefSize(50, 75);
		numero2.setStyle("-fx-background-color: #1F2937;-fx-text-fill: #D1D5D6;");
		Button numero3 = new Button(numeros[2] + "");
		numero3.setPrefSize(50, 75);
		numero3.setStyle("-fx-background-color: #1F2937;-fx-text-fill: #D1D5D6;");
		Button numero4 = new Button(numeros[3] + "");
		numero4.setPrefSize(50, 75);
		numero4.setStyle("-fx-background-color: #1F2937;-fx-text-fill: #D1D5D6;");
		Button numero5 = new Button(numeros[4] + "");
		numero5.setPrefSize(50, 75);
		numero5.setStyle("-fx-background-color: #1F2937;-fx-text-fill: #D1D5D6;");
		Button numero6 = new Button(numeros[5] + "");
		numero6.setPrefSize(50, 75);
		numero6.setStyle("-fx-background-color: #1F2937;-fx-text-fill: #D1D5D6;");

		// SIGNOS
		Button parentesisA = new Button("(");
		parentesisA.setPrefSize(50, 75);
		parentesisA.setStyle("-fx-background-color: #F97316;-fx-text-fill: #D1D5D6;");
		Button parentesisC = new Button(")");
		parentesisC.setPrefSize(50, 75);
		parentesisC.setStyle("-fx-background-color: #F97316;-fx-text-fill: #D1D5D6;");
		Button suma = new Button("+");
		suma.setPrefSize(50, 75);
		suma.setStyle("-fx-background-color: #F97316;-fx-text-fill: #D1D5D6;");
		Button resta = new Button("-");
		resta.setPrefSize(50, 75);
		resta.setStyle("-fx-background-color: #F97316;-fx-text-fill: #D1D5D6;");
		Button multiplicacion = new Button("*");
		multiplicacion.setPrefSize(50, 75);
		multiplicacion.setStyle("-fx-background-color: #F97316;-fx-text-fill: #D1D5D6;");
		Button division = new Button("/");
		division.setPrefSize(50, 75);
		division.setStyle("-fx-background-color: #F97316;-fx-text-fill: #D1D5D6;");
		Button delete = new Button("DEL");
		delete.setPrefSize(50, 75);
		delete.setStyle("-fx-background-color: #EF4444;-fx-text-fill: #D1D5D6;");
		Button igual = new Button("=");
		igual.setPrefSize(50, 100);
		igual.setStyle("-fx-background-color: #F97316;-fx-text-fill: #D1D5D6;");

		Label lResultado = new Label(resultado + "");
		lResultado.setStyle(
				"-fx-border-color: black; -fx-border-width: 5px; -fx-border-radius: 10px;  -fx-padding: 10px;");
		Label operacion = new Label();
		operacion.setPrefSize(250,100);
		operacion.setStyle("-fx-background-color: #CBD5E1;");
		Label operaciones = new Label();
		operaciones.setPrefSize(250, 200);
		operaciones.setStyle("-fx-background-color: #CBD5E1;");
		VBox primerosNum = new VBox(10);
		primerosNum.setAlignment(Pos.CENTER);
		primerosNum.getChildren().addAll(numero1, numero4);
		VBox segundosNum = new VBox(10);
		segundosNum.setAlignment(Pos.CENTER);
		segundosNum.getChildren().addAll(numero2, numero5);
		VBox tercerosNum = new VBox(10);
		tercerosNum.setAlignment(Pos.CENTER);
		tercerosNum.getChildren().addAll(numero3, numero6);
		HBox cajaNumeros = new HBox(10);
		cajaNumeros.setAlignment(Pos.CENTER);
		cajaNumeros.getChildren().addAll(primerosNum, segundosNum, tercerosNum);

		Label lSolucion = new Label();

		Button rendirse = new Button("Rendirse");
		rendirse.setOnAction(e -> {
			lSolucion.setText(solucion);
			lSolucion.setStyle("-fx-background-color: #EF4444;");
		});
		rendirse.setStyle("-fx-background-color: #EF4444;");
		rendirse.setPrefSize(75, 50);

		VBox primerosSig = new VBox(10);
		primerosSig.setAlignment(Pos.CENTER);
		primerosSig.getChildren().addAll(parentesisA, suma, multiplicacion);
		VBox segundosSig = new VBox(10);
		segundosSig.setAlignment(Pos.CENTER);
		segundosSig.getChildren().addAll(parentesisC, resta, division);
		VBox igualDelete = new VBox(10);
		igualDelete.setAlignment(Pos.CENTER);
		igualDelete.getChildren().addAll(delete, igual);
		HBox cajaSignos = new HBox(10);
		cajaSignos.setAlignment(Pos.CENTER);
		cajaSignos.getChildren().addAll(primerosSig, segundosSig, igualDelete);

		HBox calculadora = new HBox(10);
		calculadora.setAlignment(Pos.CENTER);
		calculadora.getChildren().addAll(cajaNumeros, cajaSignos);

		numero1.setOnAction(e -> {
			if (numOSig) {
				numero1.setDisable(true);
				operacion.setText(operacion.getText() + numeros[0]);
				actualizarNumerico(1);
				actualizar(operacion.getText());
				cambiarNumOSig();
			}
		});
		numero2.setOnAction(e -> {
			if (numOSig) {
				numero2.setDisable(true);
				operacion.setText(operacion.getText() + numeros[1]);
				actualizar(operacion.getText());
				actualizarNumerico(2);
				cambiarNumOSig();
			}
		});
		numero3.setOnAction(e -> {
			if (numOSig) {
				numero3.setDisable(true);
				operacion.setText(operacion.getText() + numeros[2]);
				actualizar(operacion.getText());
				actualizarNumerico(3);
				cambiarNumOSig();
			}
		});
		numero4.setOnAction(e -> {
			if (numOSig) {
				numero4.setDisable(true);
				operacion.setText(operacion.getText() + numeros[3]);
				actualizar(operacion.getText());
				actualizarNumerico(4);
				cambiarNumOSig();
			}
		});
		numero5.setOnAction(e -> {
			if (numOSig) {
				numero5.setDisable(true);
				operacion.setText(operacion.getText() + numeros[4]);
				actualizar(operacion.getText());
				actualizarNumerico(5);
				cambiarNumOSig();
			}
		});
		numero6.setOnAction(e -> {
			if (numOSig) {
				numero6.setDisable(true);
				operacion.setText(operacion.getText() + numeros[5]);
				actualizar(operacion.getText());
				actualizarNumerico(6);
				cambiarNumOSig();
			}
		});

		suma.setOnAction(e -> {
			if (numOSig) {}else {
				operacion.setText(operacion.getText() + "+");
				actualizar(operacion.getText());
				cambiarNumOSig();
			}
		});
		resta.setOnAction(e -> {
			if (numOSig) {}else {
				operacion.setText(operacion.getText() + "-");
				actualizar(operacion.getText());
				cambiarNumOSig();
			}
		});
		multiplicacion.setOnAction(e -> {
			if (numOSig) {}else {
				operacion.setText(operacion.getText() + "*");
				actualizar(operacion.getText());
				cambiarNumOSig();
			}
		});
		division.setOnAction(e -> {
			if (numOSig) {}else {
				operacion.setText(operacion.getText() + "/");
				actualizar(operacion.getText());
				cambiarNumOSig();
			}
		});
		parentesisA.setOnAction(e -> {
			operacion.setText(operacion.getText() + "(");
			actualizar(operacion.getText());
			cambiarParentesis();
		});
		parentesisC.setOnAction(e -> {
			operacion.setText(operacion.getText() + ")");
			actualizar(operacion.getText());
			cambiarParentesis();
		});
		delete.setOnAction(e -> {
			operacion.setText(delete(operacion.getText()));
			if(historialNumerico.size()==0) {
				
			}else {
			switch (historialNumerico.get(historialNumerico.size()-1)) {
			case 1:
				numero1.setDisable(false);
				break;
			case 2:
				numero2.setDisable(false);
				break;
			case 3:
				numero3.setDisable(false);
				break;
			case 4:
				numero4.setDisable(false);
				break;
			case 5:
				numero5.setDisable(false);
				break;
			case 6:
				numero6.setDisable(false);
				break;
				
			}}
				
		});
		
		igual.setOnAction(e -> {
			if (parentesis) {
			} else {
				int resultadoOperacion = calcular(operacion.getText());
				if (resultadoOperacion == getResultado()) {
					lSolucion.setText("Ganaste");
					lSolucion.setStyle("-fx-background-color: #B5E61D");
				} else {
					numero1.setDisable(false);
					numero2.setDisable(false);
					numero3.setDisable(false);
					numero4.setDisable(false);
					numero5.setDisable(false);
					numero6.setDisable(false);
					borrarHistorial();
					borrarHistorialNumerico();
					setNumOSig(true);
					operaciones.setText(operaciones.getText()+operacion.getText()+"="+resultadoOperacion+"\n");
					operacion.setText("");
				}
			}
		});
		VBox principal = new VBox(50);
		principal.getChildren().addAll(label, lResultado, lSolucion,operaciones, operacion, rendirse, calculadora, fin);
		principal.setBackground(
				new Background(new BackgroundFill(Color.web("#E2E8F0"), CornerRadii.EMPTY, Insets.EMPTY)));
		principal.setAlignment(Pos.CENTER);
		principal.setPadding(new Insets(10));
		ventana.setScene(new Scene(principal, 1200, 720));

		ventana.show();
	}

	public static int calcular(String operacion) {
		try {
			List<String> postfix = Calculadora.infixToPostfix(operacion);
			double resultado = Calculadora.evaluatePostfix(postfix);
			return (int) resultado;
		} catch (Exception e) {

			return 0;
		}
	}
}
