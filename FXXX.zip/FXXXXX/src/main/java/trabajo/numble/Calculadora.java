package trabajo.numble;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Deque;
import java.util.List;
import java.util.StringTokenizer;

public class Calculadora {
	public static List<String> infixToPostfix(String expression) throws Exception {
        List<String> output = new ArrayList<>();
        Deque<Character> operators = new ArrayDeque<>();
        StringTokenizer tokens = new StringTokenizer(expression, "+-*/() ", true);
        
        while (tokens.hasMoreTokens()) {
            String token = tokens.nextToken().trim();
            if (token.isEmpty()) continue;
            
            if (isNumber(token)) {
                output.add(token);
            } else if (isOperator(token)) {
                while (!operators.isEmpty() && precedence(operators.peek()) >= precedence(token.charAt(0))) {
                    output.add(String.valueOf(operators.pop()));
                }
                operators.push(token.charAt(0));
            } else if (token.equals("(")) {
                operators.push('(');
            } else if (token.equals(")")) {
                while (!operators.isEmpty() && operators.peek() != '(') {
                    output.add(String.valueOf(operators.pop()));
                }
                if (operators.isEmpty() || operators.pop() != '(') {
                    throw new Exception("Paréntesis desbalanceados");
                }
            } else {
                throw new Exception("Carácter no válido en la expresión");
            }
        }
        
        while (!operators.isEmpty()) {
            char op = operators.pop();
            if (op == '(' || op == ')') {
                throw new Exception("Paréntesis desbalanceados");
            }
            output.add(String.valueOf(op));
        }
        
        return output;
    }

	public static double evaluatePostfix(List<String> postfix) throws Exception {
        Deque<Double> stack = new ArrayDeque<>();
        
        for (String token : postfix) {
            if (isNumber(token)) {
                stack.push(Double.parseDouble(token));
            } else if (isOperator(token)) {
                double b = stack.pop();
                double a = stack.pop();
                switch (token.charAt(0)) {
                    case '+': stack.push(a + b); break;
                    case '-': stack.push(a - b); break;
                    case '*': stack.push(a * b); break;
                    case '/': stack.push(a / b); break;
                    default: throw new Exception("Operador no válido");
                }
            } else {
                throw new Exception("Token no válido en la expresión postfix");
            }
        }
        
        if (stack.size() != 1) {
            throw new Exception("Error en la evaluación de la expresión");
        }
        
        return stack.pop();
    }

	public static boolean isNumber(String token) {
        try {
            Double.parseDouble(token);
            return true;
        } catch (NumberFormatException e) {
            return false;
        }
    }

	public static boolean isOperator(String token) {
        return token.length() == 1 && "+-*/".contains(token);
    }

	public static int precedence(char operator) {
        switch (operator) {
            case '+':
            case '-': return 1;
            case '*':
            case '/': return 2;
            default: return -1;
        }
    }
}
